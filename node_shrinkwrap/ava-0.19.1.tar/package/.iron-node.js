module.exports = {
	app: {
		openDevToolsDetached: true,
		hideMainWindow: true
	},
	workSpaceDirectory: () => __dirname
};
