1.2.1 / 2016-02-01
==================
 * fix: only call decodeURIComponent once so you can encode % #11 [sal89](https://github.com/sal89)

1.2.0 / 2016-01-16
==================
 * fix: call decodeURIComponent on username and password #9

1.1.1 / 2016-09-26
==================
 * fixed; handle parsing of replicaSet with leading number #8

1.1.0 / 2015-04-13
==================
 * added; parse ipv6 addresses

1.0.0 / 2014-10-18
==================

 * fixed; compatibility w/ strict mode #4 [vkarpov15](https://github.com/vkarpov15)

0.3.1 / 2013-02-17
==================

  * fixed; allow '#' in username and password #3

0.3.0 / 2013-01-14
==================

  * fixed; default db logic #2

0.2.0 / 2013-01-09
==================

  * changed; default db is now 'test'

0.1.0 / 2012-12-18
==================

  * changed; include .sock in UDS

0.0.5 / 2012-12-18
==================

  * fixed; unix domain sockets used with db names

0.0.4 / 2012-12-01
==================

  * handle multple specified protocols

0.0.3 / 2012-11-29
==================

  * validate mongodb:///db
  * more detailed error message

0.0.2 / 2012-11-02
==================

  * add readPreferenceTags support
  * add unix domain support

0.0.1 / 2012-11-01
==================

  * initial release
