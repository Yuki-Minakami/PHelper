
1.2.0 - November 25, 2014
-------------------------
* add support for protocol relative urls

1.1.0 - February 8, 2013
------------------------
* support any protocol
* support paths on localhost

1.0.0 - January 17, 2013
------------------------
* allow localhost to have a port

0.1.0 - September 8, 2013
-------------------------
* make regexp match more valid url types

0.0.2 - August 2, 2013
----------------------
* remove loose matching

0.0.1 - August 2, 2013
----------------------
:sparkles: