# is-url

  Check whether a string is a URL.

## Installation

```
$ component install segmentio/is-url
```
```
$ npm install is-url
```

## API

### isUrl(string)

  Checks whether `string` is a URL.

## License

  MIT
