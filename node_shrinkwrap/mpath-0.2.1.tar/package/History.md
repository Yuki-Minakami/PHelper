
0.2.1 / 2013-03-22
==================

  * test; added for #5
  * fix typo that breaks set #5 [Contra](https://github.com/Contra)

0.2.0 / 2013-03-15
==================

  * added; adapter support for set
  * added; adapter support for get
  * add basic benchmarks
  * add support for using module as a component #2 [Contra](https://github.com/Contra)

0.1.1 / 2012-12-21
==================

  * added; map support

0.1.0 / 2012-12-13
==================

  * added; set('array.property', val, object) support
  * added; get('array.property', object) support

0.0.1 / 2012-11-03
==================

  * initial release
