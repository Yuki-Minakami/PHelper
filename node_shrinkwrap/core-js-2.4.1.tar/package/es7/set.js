require('../modules/es7.set.to-json');
module.exports = require('../modules/_core').Set;