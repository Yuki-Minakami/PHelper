require('../modules/es6.parse-int');
module.exports = require('../modules/_core').parseInt;