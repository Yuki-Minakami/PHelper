require('../../modules/es6.typed.int16-array');
module.exports = require('../../modules/_core').Int16Array;