require('../../modules/es6.string.fontcolor');
module.exports = require('../../modules/_core').String.fontcolor;