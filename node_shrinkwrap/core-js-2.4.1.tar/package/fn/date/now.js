require('../../modules/es6.date.now');
module.exports = require('../../modules/_core').Date.now;