module.exports = exports = require('./lib/sliced');
