<!-- *Before creating an issue please make sure you are using the latest version of mongoose -->

**Do you want to request a *feature* or report a *bug*?**

**What is the current behavior?**

**If the current behavior is a bug, please provide the steps to reproduce.**
<!-- If you can, provide a stadalone script / gist to reproduce your issue -->

**What is the expected behavior?**

**Please mention your node.js, mongoose and MongoDB version.**
