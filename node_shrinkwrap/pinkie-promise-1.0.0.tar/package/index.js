'use strict';

module.exports = global.Promise || require('pinkie');
