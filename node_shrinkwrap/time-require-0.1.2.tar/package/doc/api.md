## API documentation for time-require

TODO: Detail usage
