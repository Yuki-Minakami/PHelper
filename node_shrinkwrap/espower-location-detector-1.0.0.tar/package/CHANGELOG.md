## [1.0.0](https://github.com/twada/espower-location-detector/releases/tag/v1.0.0) (2016-12-31)


#### Chores

  * The first stable release


### [0.1.2](https://github.com/twada/espower-location-detector/releases/tag/v0.1.2) (2016-02-10)


#### Bug Fixes

  * dealing with incoming empty SourceMap ([6f45640f](https://github.com/twada/espower-location-detector/commit/6f45640fbf4db23e327b087df8671f3d9203fb09))


### [0.1.1](https://github.com/twada/espower-location-detector/releases/tag/v0.1.1) (2015-12-31)


#### Bug Fixes

  * mark lib dir to be distributed ([ca23cce1](https://github.com/twada/espower-location-detector/commit/ca23cce1a3458658cba1623cb853635822b107bb))


## [0.1.0](https://github.com/twada/espower-location-detector/releases/tag/v0.1.0) (2015-12-31)


#### Features

  * initial release (extract espower-location-detector from espower)
