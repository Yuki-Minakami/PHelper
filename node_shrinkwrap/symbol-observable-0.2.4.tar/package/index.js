/* global window */
'use strict';

module.exports = require('./ponyfill')(global || window || this);
